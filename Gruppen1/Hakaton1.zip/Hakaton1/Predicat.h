#include <stdbool.h>

typedef bool (*predicatInt)(int);

typedef bool (*predicatDouble)(double);


